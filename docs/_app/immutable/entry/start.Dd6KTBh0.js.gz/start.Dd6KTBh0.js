import{s as t}from"../chunks/vendor.BVhHomP9.js";export{t as start};
