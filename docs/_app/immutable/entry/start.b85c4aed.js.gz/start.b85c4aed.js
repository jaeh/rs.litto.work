import{s as t}from"../chunks/vendor.13eb4b7c.js";export{t as start};
