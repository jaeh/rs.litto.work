import{s as t}from"../chunks/vendor.Bha-GW5L.js";export{t as start};
