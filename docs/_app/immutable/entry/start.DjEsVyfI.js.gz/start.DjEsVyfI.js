import{s as t}from"../chunks/vendor.Krcbe079.js";export{t as start};
