import{s as t}from"../chunks/vendor.BWae0U8a.js";export{t as start};
