import{s as t}from"../chunks/vendor.D29GyqJL.js";export{t as start};
