import{s as t}from"../chunks/vendor.HlrxR3Q_.js";export{t as start};
