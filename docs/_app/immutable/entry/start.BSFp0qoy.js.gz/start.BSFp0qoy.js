import{s as t}from"../chunks/vendor.DTNFBlIs.js";export{t as start};
