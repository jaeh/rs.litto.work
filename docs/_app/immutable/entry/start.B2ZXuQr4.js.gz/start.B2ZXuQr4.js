import{s as t}from"../chunks/vendor.BFdG4HDv.js";export{t as start};
