import{s as t}from"../chunks/vendor.DZZfonmu.js";export{t as start};
