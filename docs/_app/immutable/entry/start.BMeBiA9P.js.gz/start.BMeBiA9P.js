import{s as t}from"../chunks/vendor.BgxAvvB6.js";export{t as start};
