import{s as t}from"../chunks/vendor.4ba4ffa5.js";export{t as start};
