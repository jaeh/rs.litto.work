import{s as t}from"../chunks/vendor.C0_1eJys.js";export{t as start};
