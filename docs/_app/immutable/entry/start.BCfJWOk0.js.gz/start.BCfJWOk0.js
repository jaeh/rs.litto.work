import{s as t}from"../chunks/vendor.CKTEncrA.js";export{t as start};
