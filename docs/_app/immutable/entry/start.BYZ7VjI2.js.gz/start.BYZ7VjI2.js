import{s as t}from"../chunks/vendor.D-heZ_33.js";export{t as start};
