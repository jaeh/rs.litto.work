import{s as t}from"../chunks/vendor.CHWvru6D.js";export{t as start};
