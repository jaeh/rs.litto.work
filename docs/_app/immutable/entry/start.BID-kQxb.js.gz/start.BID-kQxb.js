import{s as t}from"../chunks/vendor.BjIHKs1D.js";export{t as start};
