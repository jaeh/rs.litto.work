import{s as t}from"../chunks/vendor.CPZqgyak.js";export{t as start};
