import{s as t}from"../chunks/vendor.Ak7YUK4J.js";export{t as start};
