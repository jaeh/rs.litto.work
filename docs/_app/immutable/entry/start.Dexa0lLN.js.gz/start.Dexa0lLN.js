import{s as t}from"../chunks/vendor.C-ThwTav.js";export{t as start};
