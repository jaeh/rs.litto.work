import{s as t}from"../chunks/vendor.C-5OdM_S.js";export{t as start};
