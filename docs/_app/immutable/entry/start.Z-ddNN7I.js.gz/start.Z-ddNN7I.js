import{s as t}from"../chunks/vendor.Bry4U2Jn.js";export{t as start};
