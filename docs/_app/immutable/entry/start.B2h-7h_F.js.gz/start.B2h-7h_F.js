import{s as t}from"../chunks/vendor.-TG531Kx.js";export{t as start};
