import{s as t}from"../chunks/vendor.Dw1-32j7.js";export{t as start};
