import{s as t}from"../chunks/vendor.JWPsxHGB.js";export{t as start};
