import{s as t}from"../chunks/vendor.C5pu8vC7.js";export{t as start};
