import{s as t}from"../chunks/vendor.DylqxnAC.js";export{t as start};
