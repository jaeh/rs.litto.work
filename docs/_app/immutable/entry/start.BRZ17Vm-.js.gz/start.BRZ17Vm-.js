import{s as t}from"../chunks/vendor.DA0mBmRR.js";export{t as start};
