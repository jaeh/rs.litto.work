import{s as t}from"../chunks/vendor.DAZdXhRg.js";export{t as start};
