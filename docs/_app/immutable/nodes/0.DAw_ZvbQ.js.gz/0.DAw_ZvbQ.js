import{L as e,_ as n}from"../chunks/vendor.-TG531Kx.js";export{e as component,n as universal};
