import{L as e,_ as n}from"../chunks/vendor.4ba4ffa5.js";export{e as component,n as universal};
