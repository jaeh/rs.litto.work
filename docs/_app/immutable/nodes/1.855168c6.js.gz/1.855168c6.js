import{E as m}from"../chunks/vendor.4ba4ffa5.js";export{m as component};
