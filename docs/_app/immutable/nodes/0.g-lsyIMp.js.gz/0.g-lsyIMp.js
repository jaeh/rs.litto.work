import{L as e,_ as n}from"../chunks/vendor.BoA-wVdt.js";export{e as component,n as universal};
