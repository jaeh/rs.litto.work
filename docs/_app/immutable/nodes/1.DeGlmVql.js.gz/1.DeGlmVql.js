import{E as m}from"../chunks/vendor.C0_1eJys.js";export{m as component};
