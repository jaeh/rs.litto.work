import{L as e,_ as n}from"../chunks/vendor.13eb4b7c.js";export{e as component,n as universal};
