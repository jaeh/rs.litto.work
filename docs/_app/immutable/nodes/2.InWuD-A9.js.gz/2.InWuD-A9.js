import{P as m}from"../chunks/vendor.Bry4U2Jn.js";export{m as component};
