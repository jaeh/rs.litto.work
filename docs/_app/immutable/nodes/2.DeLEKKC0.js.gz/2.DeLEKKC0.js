import{P as m}from"../chunks/vendor.Krcbe079.js";export{m as component};
