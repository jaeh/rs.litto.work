import{L as e,_ as n}from"../chunks/vendor.CZ-jcrWr.js";export{e as component,n as universal};
