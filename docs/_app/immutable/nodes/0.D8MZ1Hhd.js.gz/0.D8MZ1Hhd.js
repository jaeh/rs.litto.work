import{L as e,_ as n}from"../chunks/vendor.Bha-GW5L.js";export{e as component,n as universal};
