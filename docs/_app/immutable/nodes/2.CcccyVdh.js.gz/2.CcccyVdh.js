import{P as m}from"../chunks/vendor.Bha-GW5L.js";export{m as component};
