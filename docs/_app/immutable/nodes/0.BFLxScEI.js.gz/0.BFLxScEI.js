import{L as e,_ as n}from"../chunks/vendor.DTNFBlIs.js";export{e as component,n as universal};
