import{L as e,_ as n}from"../chunks/vendor.C-5OdM_S.js";export{e as component,n as universal};
