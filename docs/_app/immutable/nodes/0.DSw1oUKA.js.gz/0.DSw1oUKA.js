import{L as e,_ as n}from"../chunks/vendor.C0_1eJys.js";export{e as component,n as universal};
