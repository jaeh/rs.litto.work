import{P as m}from"../chunks/vendor.CZ-jcrWr.js";export{m as component};
