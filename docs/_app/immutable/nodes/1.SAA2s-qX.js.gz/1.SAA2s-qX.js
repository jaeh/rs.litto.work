import{E as m}from"../chunks/vendor.BgxAvvB6.js";export{m as component};
