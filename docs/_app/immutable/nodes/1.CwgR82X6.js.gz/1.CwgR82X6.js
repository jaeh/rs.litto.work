import{E as m}from"../chunks/vendor.-TG531Kx.js";export{m as component};
