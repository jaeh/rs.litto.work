import{E as m}from"../chunks/vendor.DTNFBlIs.js";export{m as component};
