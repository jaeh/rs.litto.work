import{P as m}from"../chunks/vendor.13eb4b7c.js";export{m as component};
