import{E as m}from"../chunks/vendor.D-heZ_33.js";export{m as component};
