import{L as e,_ as n}from"../chunks/vendor.D29GyqJL.js";export{e as component,n as universal};
