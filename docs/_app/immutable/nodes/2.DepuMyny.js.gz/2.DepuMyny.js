import{P as m}from"../chunks/vendor.D29GyqJL.js";export{m as component};
