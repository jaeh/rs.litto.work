import{E as m}from"../chunks/vendor.C-5OdM_S.js";export{m as component};
