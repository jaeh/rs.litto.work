import{P as m}from"../chunks/vendor.C5pu8vC7.js";export{m as component};
