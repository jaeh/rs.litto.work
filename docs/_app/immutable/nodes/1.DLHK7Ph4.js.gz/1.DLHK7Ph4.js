import{E as m}from"../chunks/vendor.C-ThwTav.js";export{m as component};
