import{P as m}from"../chunks/vendor.CPZqgyak.js";export{m as component};
