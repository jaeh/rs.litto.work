import{E as m}from"../chunks/vendor.Ak7YUK4J.js";export{m as component};
