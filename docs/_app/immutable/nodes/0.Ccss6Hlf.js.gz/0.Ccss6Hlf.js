import{L as e,_ as n}from"../chunks/vendor.DZZfonmu.js";export{e as component,n as universal};
