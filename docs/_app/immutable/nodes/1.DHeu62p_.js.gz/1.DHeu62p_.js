import{E as m}from"../chunks/vendor.BVhHomP9.js";export{m as component};
