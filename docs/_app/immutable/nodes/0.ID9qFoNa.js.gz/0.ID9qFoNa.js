import{L as e,_ as n}from"../chunks/vendor.Bry4U2Jn.js";export{e as component,n as universal};
