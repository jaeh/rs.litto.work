import{L as e,_ as n}from"../chunks/vendor.BWae0U8a.js";export{e as component,n as universal};
