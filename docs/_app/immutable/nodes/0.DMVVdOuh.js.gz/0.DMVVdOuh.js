import{L as e,_ as n}from"../chunks/vendor.CPZqgyak.js";export{e as component,n as universal};
