import{E as m}from"../chunks/vendor.CHWvru6D.js";export{m as component};
