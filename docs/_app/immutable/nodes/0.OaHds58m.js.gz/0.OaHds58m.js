import{L as e,_ as n}from"../chunks/vendor.DA0mBmRR.js";export{e as component,n as universal};
