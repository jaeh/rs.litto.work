import{L as e,_ as n}from"../chunks/vendor.Krcbe079.js";export{e as component,n as universal};
