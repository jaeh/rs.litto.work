import{P as m}from"../chunks/vendor.CKTEncrA.js";export{m as component};
