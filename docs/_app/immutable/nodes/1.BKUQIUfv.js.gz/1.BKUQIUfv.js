import{E as m}from"../chunks/vendor.HlrxR3Q_.js";export{m as component};
