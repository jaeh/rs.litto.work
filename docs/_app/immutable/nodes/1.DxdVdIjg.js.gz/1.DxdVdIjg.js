import{E as m}from"../chunks/vendor.BFdG4HDv.js";export{m as component};
