import{P as m}from"../chunks/vendor.DZZfonmu.js";export{m as component};
