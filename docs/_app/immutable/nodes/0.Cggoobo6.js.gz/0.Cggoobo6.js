import{L as e,_ as n}from"../chunks/vendor.HlrxR3Q_.js";export{e as component,n as universal};
