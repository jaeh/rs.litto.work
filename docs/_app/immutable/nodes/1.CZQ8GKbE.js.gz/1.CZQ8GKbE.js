import{E as m}from"../chunks/vendor.Dw1-32j7.js";export{m as component};
