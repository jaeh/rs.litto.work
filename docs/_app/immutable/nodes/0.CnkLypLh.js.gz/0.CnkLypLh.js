import{L as e,_ as n}from"../chunks/vendor.C5pu8vC7.js";export{e as component,n as universal};
