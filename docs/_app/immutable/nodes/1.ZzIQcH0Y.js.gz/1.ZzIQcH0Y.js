import{E as m}from"../chunks/vendor.DAZdXhRg.js";export{m as component};
