import{E as m}from"../chunks/vendor.DylqxnAC.js";export{m as component};
