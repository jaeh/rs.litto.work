import{L as e,_ as n}from"../chunks/vendor.BFdG4HDv.js";export{e as component,n as universal};
