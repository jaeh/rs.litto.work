import{E as m}from"../chunks/vendor.BoA-wVdt.js";export{m as component};
