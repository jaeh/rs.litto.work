import{E as m}from"../chunks/vendor.BWae0U8a.js";export{m as component};
