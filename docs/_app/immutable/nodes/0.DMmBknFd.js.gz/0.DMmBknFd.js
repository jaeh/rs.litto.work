import{L as e,_ as n}from"../chunks/vendor.Dw1-32j7.js";export{e as component,n as universal};
