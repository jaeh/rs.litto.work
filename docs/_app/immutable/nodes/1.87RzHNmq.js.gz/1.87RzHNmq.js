import{E as m}from"../chunks/vendor.DHOGy2xj.js";export{m as component};
