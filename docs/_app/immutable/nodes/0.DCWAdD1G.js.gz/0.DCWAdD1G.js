import{L as e,_ as n}from"../chunks/vendor.BjIHKs1D.js";export{e as component,n as universal};
