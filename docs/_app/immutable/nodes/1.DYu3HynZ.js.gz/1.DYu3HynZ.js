import{E as m}from"../chunks/vendor.BjIHKs1D.js";export{m as component};
