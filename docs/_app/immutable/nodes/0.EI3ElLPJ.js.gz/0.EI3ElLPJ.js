import{L as e,_ as n}from"../chunks/vendor.CKTEncrA.js";export{e as component,n as universal};
