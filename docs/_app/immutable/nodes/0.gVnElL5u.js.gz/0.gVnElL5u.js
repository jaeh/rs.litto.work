import{L as e,_ as n}from"../chunks/vendor.Ak7YUK4J.js";export{e as component,n as universal};
