import{L as e,_ as n}from"../chunks/vendor.CHWvru6D.js";export{e as component,n as universal};
