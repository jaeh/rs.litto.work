import{P as m}from"../chunks/vendor.DA0mBmRR.js";export{m as component};
